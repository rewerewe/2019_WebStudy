package com.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.util.DBConn;

public class SalgradeDAO
{
   private Connection conn;

   public Connection connection() throws ClassNotFoundException, SQLException
   {
      conn = DBConn.getConnection();
      return conn;
   }

   public int add(SalgradeDTO dto) throws SQLException
   {
      int result = 0;

      String sql = "INSERT INTO SALGRADE(GRADE, LOSAL, HISAL) VALUES(?, ?, ?)";

      PreparedStatement pstmt = conn.prepareStatement(sql);

      pstmt.setString(1, dto.getGrade());
      pstmt.setInt(2, dto.getLosal());
      pstmt.setInt(3, dto.getHisal());

      result = pstmt.executeUpdate();

      pstmt.close();

      return result;
   }

   public int updateSal(SalgradeDTO dto) throws SQLException
   {
      int result = 0;

      String sql = "UPDATE SALGRADE SET LOSAL = ? , HISAL = ? WHERE GRADE = ?";

      PreparedStatement pstmt = conn.prepareStatement(sql);

      pstmt.setInt(1, dto.getLosal());
      pstmt.setInt(2, dto.getHisal());
      pstmt.setString(3, dto.getGrade());

      result = pstmt.executeUpdate();

      pstmt.close();

      return result;

   }

   public ArrayList<SalgradeDTO> lists() throws SQLException
   {
      ArrayList<SalgradeDTO> result = new ArrayList<SalgradeDTO>();

      String sql = "SELECT GRADE,LOSAL,HISAL FROM SALGRADE";

      PreparedStatement pstmt = conn.prepareStatement(sql);

      ResultSet rs = pstmt.executeQuery();

      while (rs.next())
      {
         SalgradeDTO dto = new SalgradeDTO();

         dto.setGrade(rs.getString("GRADE"));
         dto.setLosal(rs.getInt("LOSAL"));
         dto.setHisal(rs.getInt("HISAL"));

         result.add(dto);
      }

      rs.close();
      pstmt.close();

      return result;
   }

   public int removeSal(String grade) throws SQLException
   {
      int result = 0;

      String sql = "DELETE FROM SALGRADE WHERE GRADE = ?";

      PreparedStatement pstmt = conn.prepareStatement(sql);

      pstmt.setString(1, grade);

      result = pstmt.executeUpdate();

      pstmt.close();

      return result;
   }

   public void close() throws SQLException
   {
      DBConn.close();
   }
}