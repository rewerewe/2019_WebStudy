package com.test;

public class EmpDTO
{
	String empno;
	String ename;
	String job;
	String mgr;
	int sal;
	int comm;
	String deptno;
	// 지혜추가
	String deptName;
	public String getDeptName()
	{
		return deptName;
	}

	public void setDeptName(String deptName)
	{
		this.deptName = deptName;
	}

	// hiredate의 타입은 바뀔수 있음
	String hiredate;

	// 기승 추가
	String dname;
	String grade;
	String loc;
	
	

	public String getLoc()
	{
		return loc;
	}

	public void setLoc(String loc)
	{
		this.loc = loc;
	}

	public String getGrade()
	{
		return grade;
	}

	public void setGrade(String grade)
	{
		this.grade = grade;
	}

	int pay;
	
	
	public String getDname()
	{
		return dname;
	}

	public void setDname(String dname)
	{
		this.dname = dname;
	}

	public int getPay()
	{
		return pay;
	}

	public void setPay(int pay)
	{
		this.pay = pay;
	}

	public String getEmpno()
	{
		return empno;
	}

	public void setEmpno(String empno)
	{
		this.empno = empno;
	}

	public String getEname()
	{
		return ename;
	}

	public void setEname(String ename)
	{
		this.ename = ename;
	}

	public String getJob()
	{
		return job;
	}

	public void setJob(String job)
	{
		this.job = job;
	}

	public String getMgr()
	{
		return mgr;
	}

	public void setMgr(String mgr)
	{
		this.mgr = mgr;
	}

	public int getSal()
	{
		return sal;
	}

	public void setSal(int sal)
	{
		this.sal = sal;
	}

	public int getComm()
	{
		return comm;
	}

	public void setComm(int comm)
	{
		this.comm = comm;
	}

	public String getDeptno()
	{
		return deptno;
	}

	public void setDeptno(String deptno)
	{
		this.deptno = deptno;
	}

	public String getHiredate()
	{
		return hiredate;
	}

	public void setHiredate(String hiredate)
	{
		this.hiredate = hiredate;
	}
	
	
}
