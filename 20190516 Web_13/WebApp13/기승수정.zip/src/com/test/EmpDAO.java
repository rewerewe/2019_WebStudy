package com.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.util.DBConn;

public class EmpDAO
{
	private Connection conn;
	
	public Connection connection() throws ClassNotFoundException, SQLException
	{
		conn=DBConn.getConnection();
		return conn;
	}
	
	// 전체 및 부서 출력
	public ArrayList<EmpDTO> empManageLists(int deptno) throws SQLException
	{
		ArrayList<EmpDTO> lists = new ArrayList<EmpDTO>();
		
		String sql = "SELECT * FROM VIEW_EMP ORDER BY EMPNO";
		
		if(deptno>0)
			sql = "SELECT * FROM VIEW_EMP WHERE DNAME = (SELECT DNAME FROM DEPT WHERE DEPTNO = "+deptno+") ORDER BY EMPNO";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next())
		{
			EmpDTO dto = new EmpDTO();
			
			dto.setEmpno(rs.getString("EMPNO"));
			dto.setEname(rs.getString("ENAME"));
			dto.setJob(rs.getString("JOB"));
			dto.setMgr(rs.getString("MGR"));
			dto.setHiredate(rs.getString("HIREDATE"));
			dto.setSal(rs.getInt("SAL"));
			dto.setComm(rs.getInt("COMM"));
			dto.setPay(rs.getInt("PAY"));
			dto.setDname(rs.getString("DNAME"));
			dto.setGrade(rs.getString("GRADE"));
			dto.setLoc(rs.getString("LOC"));
			lists.add(dto);
		}
		
		rs.close();
		pstmt.close();
		
		return lists;
	}
	
	// Search
	public ArrayList<EmpDTO> empManageLists(String search) throws SQLException
	{
		ArrayList<EmpDTO> lists = new ArrayList<EmpDTO>();
		
		String sql = "SELECT * FROM VIEW_EMP WHERE EMPNO LIKE '%"+search+"%' OR ENAME LIKE '%"+search+"%' OR JOB LIKE '%"+search+"%' OR MGR LIKE '%"+search+"%' OR HIREDATE LIKE '%"+search+"%' OR SAL LIKE '%"+search+"%' OR COMM LIKE '%"+search+"%' OR PAY LIKE '%"+search+"%' OR DNAME LIKE '%"+search+"%' OR LOC LIKE '%"+search+"%' OR GRADE LIKE '%"+search+"%' ORDER BY EMPNO";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		
		ResultSet rs = pstmt.executeQuery();
		
		while(rs.next())
		{
			EmpDTO dto = new EmpDTO();
			
			dto.setEmpno(rs.getString("EMPNO"));
			dto.setEname(rs.getString("ENAME"));
			dto.setJob(rs.getString("JOB"));
			dto.setMgr(rs.getString("MGR"));
			dto.setHiredate(rs.getString("HIREDATE"));
			dto.setSal(rs.getInt("SAL"));
			dto.setComm(rs.getInt("COMM"));
			dto.setPay(rs.getInt("PAY"));
			dto.setDname(rs.getString("DNAME"));
			dto.setGrade(rs.getString("GRADE"));
			dto.setLoc(rs.getString("LOC"));
			lists.add(dto);
		}
		
		rs.close();
		pstmt.close();
		
		return lists;
	}
	
	public int empManageDelete(String empno) throws SQLException
	{
		int result = 0;
		
		String sql ="UPDATE EMP SET JOB=NULL, MGR=NULL, SAL=NULL, COMM=NULL WHERE EMPNO=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, empno);
		
		result = pstmt.executeUpdate();
		
		return result;
	}

	
	public void close() throws SQLException
	{
		DBConn.close();
	}
}
