package com.test;

public class DeptDTO
{
   String deptno;
   String ename;
   String empno;
   String dname;
   String loc;
   public String getDeptno()
   {
      return deptno;
   }
   public void setDeptno(String deptno)
   {
      this.deptno = deptno;
   }
   public String getEname()
   {
      return ename;
   }
   public void setEname(String ename)
   {
      this.ename = ename;
   }
   public String getEmpno()
   {
      return empno;
   }
   public void setEmpno(String empno)
   {
      this.empno = empno;
   }
   public String getDname()
   {
      return dname;
   }
   public void setDname(String dname)
   {
      this.dname = dname;
   }
   public String getLoc()
   {
      return loc;
   }
   public void setLoc(String loc)
   {
      this.loc = loc;
   }

   

   
}