package com.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.util.DBConn;

public class DeptDAO
{
   private Connection conn;
   
   public Connection connection() throws ClassNotFoundException, SQLException
   {
      conn = DBConn.getConnection();
      return conn;
   }
   
   public ArrayList<DeptDTO> lists() throws SQLException
   {
      ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
      
      String sql ="SELECT EMPNO, ENAME, DNAME FROM BUSEOSTATUSALL";
      
      PreparedStatement pstmt = conn.prepareStatement(sql);
      
      ResultSet rs = pstmt.executeQuery();
      
      while(rs.next())
      {
         DeptDTO dto = new DeptDTO();
         
         dto.setEmpno(rs.getString("EMPNO"));
         dto.setEname(rs.getString("ENAME"));
         dto.setDname(rs.getString("DNAME"));
         
         result.add(dto);
         
      }      
      
      rs.close();
      pstmt.close();
                     
      return result;
   }
   
   public ArrayList<DeptDTO> list() throws SQLException
   {
      ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
      
      String sql ="SELECT DEPTNO,DNAME FROM DEPT";
      
      PreparedStatement pstmt = conn.prepareStatement(sql);
      
      ResultSet rs = pstmt.executeQuery();
      
      while(rs.next())
      {
         DeptDTO dto = new DeptDTO();
         
         dto.setDeptno(rs.getString("DEPTNO"));
         dto.setDname(rs.getString("DNAME"));
         
         result.add(dto);
         
      }      
      
      rs.close();
      pstmt.close();
                     
      return result;
   }
   
   public int buseoAdd(DeptDTO dto) throws SQLException
   {
      int result = 0;
      
      String sql = "INSERT INTO DEPT (DEPTNO,DNAME,LOC) VALUES ((SELECT MAX(DEPTNO)+10 FROM DEPT),?,?)";
      
      PreparedStatement pstmt = conn.prepareStatement(sql);
      
      pstmt.setString(1,dto.getDname());
      pstmt.setString(2,dto.getLoc());
      
      result = pstmt.executeUpdate();
      
      pstmt.close();
            
      return result;
   }

   
   public int buseoModify(DeptDTO dto) throws SQLException
   {
      int result = 0;
      
      String sql = "UPDATE EMP SET DEPTNO = ? WHERE EMPNO = ?"; 
      
      PreparedStatement pstmt = conn.prepareStatement(sql);
      
      pstmt.setString(1, dto.getDeptno());
      pstmt.setString(2, dto.getEmpno());
      
      result = pstmt.executeUpdate();
      
      pstmt.close();
      
      return result;
   }
   
   public ArrayList<DeptDTO> buseoList() throws SQLException
   {
      ArrayList<DeptDTO> result = new ArrayList<DeptDTO>();
      
      String sql = "SELECT DEPTNO,DNAME,LOC FROM DEPT";
      
      PreparedStatement pstmt = conn.prepareStatement(sql);
      
      ResultSet rs = pstmt.executeQuery();
      
      while(rs.next())
      {
         DeptDTO dto = new DeptDTO();
         
         dto.setDeptno(rs.getString("DEPTNO"));
         dto.setDname(rs.getString("DNAME"));
         dto.setLoc(rs.getString("LOC"));
         
         result.add(dto);
      }
      
      rs.close();
      pstmt.close();
      
      return result;
            
   }
   
   public DeptDTO serachBuseo(String deptno) throws SQLException
   {
      DeptDTO result = new DeptDTO();
            
      String sql = "SELECT DEPTNO,DNAME,LOC FROM DEPT WHERE DEPTNO = ?";
      
      PreparedStatement pstmt = conn.prepareStatement(sql);
      
      pstmt.setString(1,deptno);
      
      ResultSet rs = pstmt.executeQuery();
      
      while(rs.next())
      {
         result.setDeptno(rs.getString("DEPTNO"));
         result.setDname(rs.getString("DNAME"));
         result.setLoc(rs.getString("LOC"));
         
      }
      
      rs.close();
      pstmt.close();
            
      return result;
   }
   

   
   public DeptDTO searchEmpno(String empno) throws SQLException
   {
	   DeptDTO result = new DeptDTO();
	   
	   String sql = "SELECT EMPNO, ENAME, DNAME, DEPTNO FROM BUSEOSTATUSALL WHERE EMPNO=?";
	   
	   PreparedStatement pstmt = conn.prepareStatement(sql);
	   
	   pstmt.setString(1, empno);
	   ResultSet rs = pstmt.executeQuery();
	   while(rs.next())
	   {
		   result.setEname(rs.getString("ENAME"));
		   result.setEmpno(rs.getString("EMPNO"));
		   result.setDname(rs.getString("DNAME"));
		   result.setDeptno(rs.getString("DEPTNO"));
	   }
	   
	   rs.close();
	   pstmt.close();
	   
	   return result;
   } 
   public int modifyBuseo(DeptDTO dto) throws SQLException
   {
      int result=0;
      
      String sql= "UPDATE DEPT SET DNAME = ?, LOC= ? WHERE DEPTNO = ?";
      
      PreparedStatement pstmt = conn.prepareStatement(sql);
      
      pstmt.setString(1, dto.getDname());
      pstmt.setString(2, dto.getLoc());
      pstmt.setString(3, dto.getDeptno());
      
      result = pstmt.executeUpdate();
      
      pstmt.close();
      
      return result;
   }
   
   public int removeBuseo(String deptno) throws SQLException
   {
      int result=0;
      
      String sql= "UPDATE EMP SET DEPTNO = NULL WHERE DEPTNO = ? ";
      
      PreparedStatement pstmt = conn.prepareStatement(sql);
      
      pstmt.setString(1, deptno);

      result = pstmt.executeUpdate();
      
      pstmt.close();
      
      return result;
   }
   
   public int buseoRemoveKid(String deptno) throws SQLException
   {

      int result=0;
      
      String sql= "DELETE FROM DEPT WHERE DEPTNO = ?";
      
      PreparedStatement pstmt = conn.prepareStatement(sql);
      
      pstmt.setString(1, deptno);

      result = pstmt.executeUpdate();
      
      pstmt.close();
      
      return result;
   } 

   public void close() throws SQLException
   {
      DBConn.close();
   }
   
   
}