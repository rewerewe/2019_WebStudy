package com.test;

public class SalgradeDTO
{
	String grade;
	int losal;
	int hisal;
	
	public String getGrade()
	{
		return grade;
	}
	public void setGrade(String grade)
	{
		this.grade = grade;
	}
	public int getLosal()
	{
		return losal;
	}
	public void setLosal(int losal)
	{
		this.losal = losal;
	}
	public int getHisal()
	{
		return hisal;
	}
	public void setHisal(int hisal)
	{
		this.hisal = hisal;
	}
	
	
}
